// $ANTLR : "HELPER.g" -> "HelperLexer.java"$

/**
 * Automatically generated code, do not edit!
 * To modify, make changes to HELPER.g (ANTLR file).
 */
package antenna.preprocessor.v2.parser;

public interface HelperLexerTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int WS = 4;
	int FSLASH = 5;
	int BSLASH = 6;
	int ASLASH = 7;
	int COLON = 8;
	int DIGIT_0 = 9;
	int DIGIT_1 = 10;
	int CHAR = 11;
	int PREFIX = 12;
	int FILE = 13;
	int LITERAL_include = 14;
}
